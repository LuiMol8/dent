# src/augmentation.py
"""
Funciones para generar augmentaciones sobre imágenes y anotaciones (formato YOLO).
Usa albumentations para transformar imágenes y convertir boxes.
"""
import albumentations as A
import cv2
from pathlib import Path
import os
import numpy as np


def get_train_augmentations(img_size=640):
    return A.Compose([
        A.HorizontalFlip(p=0.5),
        A.RandomBrightnessContrast(p=0.5),
        A.ShiftScaleRotate(shift_limit=0.0625, scale_limit=0.1, rotate_limit=10, border_mode=0, p=0.5),
        A.OneOf([
            A.GaussNoise(var_limit=(10.0, 50.0)),
            A.MotionBlur(blur_limit=3)
        ], p=0.3),
        A.Resize(img_size, img_size, p=1.0)
    ], bbox_params=A.BboxParams(format='yolo', label_fields=['class_labels']))


def augment_image_with_yolo_boxes(image_path, yolo_label_path, out_image_path, out_label_path, augmenter=None):
    image = cv2.imread(str(image_path))
    h, w = image.shape[:2]

    # leer boxes YOLO: class x_center y_center w h (norm)
    bboxes = []
    labels = []
    if Path(yolo_label_path).exists():
        with open(yolo_label_path, 'r') as f:
            for l in f.readlines():
                parts = l.strip().split()
                if len(parts) >= 5:
                    cls = int(parts[0])
                    xc, yc, bw, bh = map(float, parts[1:5])
                    bboxes.append([xc, yc, bw, bh])
                    labels.append(cls)

    if augmenter is None:
        augmenter = get_train_augmentations(max(h,w))

    # Albumentations expects bbox in normalized format when format='yolo'
    augmented = augmenter(image=image, bboxes=bboxes, class_labels=labels)
    aug_img = augmented['image']
    aug_bboxes = augmented['bboxes']
    aug_labels = augmented['class_labels']

    cv2.imwrite(str(out_image_path), aug_img)
    # guardar labels
    with open(out_label_path, 'w') as f:
        for cls, bb in zip(aug_labels, aug_bboxes):
            f.write(f"{cls} {bb[0]:.6f} {bb[1]:.6f} {bb[2]:.6f} {bb[3]:.6f}\n")

    return out_image_path, out_label_path