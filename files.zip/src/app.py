# src/app.py
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel
import shutil, os, uuid
from ultralytics import YOLO
from pathlib import Path

app = FastAPI(title='Dent YOLO Inference API')

MODEL_PATH = os.environ.get('MODEL_PATH', 'runs/dental_yolo/weights/best.pt')
UPLOAD_DIR = Path('uploads')
PRED_DIR = Path('api_preds')
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)
PRED_DIR.mkdir(parents=True, exist_ok=True)

# cargar modelo globalmente (mejor performance)
try:
    model = YOLO(MODEL_PATH)
except Exception as e:
    model = None
    print('Advertencia: no se pudo cargar el modelo en arranque:', e)


class PredictParams(BaseModel):
    conf: float = 0.25


@app.post('/predict/')
async def predict(image: UploadFile = File(...), conf: float = 0.25):
    if model is None:
        raise HTTPException(status_code=503, detail='Modelo no cargado')

    uid = str(uuid.uuid4())
    filename = uid + '_' + image.filename
    file_path = UPLOAD_DIR / filename
    with open(file_path, 'wb') as buffer:
        shutil.copyfileobj(image.file, buffer)

    # Ejecutar inferencia
    results = model.predict(source=str(file_path), conf=conf, save=True, save_dir=str(PRED_DIR))

    # ultralytics guarda salida en PRED_DIR con mismo nombre
    files = list(PRED_DIR.glob('*'))
    if files:
        return FileResponse(files[-1], media_type='image/png')

    return {'message': 'Predicción completada', 'details': str(results)}