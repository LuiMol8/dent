# src/dataset_utils.py
"""
Utilities para validar y explorar dataset en formato YOLO.
"""
from pathlib import Path
import os
import cv2
import numpy as np
import random
from sklearn.model_selection import train_test_split
import shutil
import json


def list_images(folder, exts=['.jpg', '.jpeg', '.png', '.bmp', '.dcm']):
    p = Path(folder)
    return [str(f) for f in p.rglob('*') if f.suffix.lower() in exts]


def check_label_exists(img_path, labels_root):
    img = Path(img_path)
    rel = img.relative_to(Path('data/images'))
    label = Path(labels_root) / rel.parent / (img.stem + '.txt')
    return label.exists()


def convert_dicom_to_png(dicom_path, out_path):
    import pydicom
    ds = pydicom.dcmread(dicom_path)
    arr = ds.pixel_array
    # Normalizar
    arr = arr.astype(float)
    arr = (np.maximum(arr,0) / arr.max()) * 255.0
    arr = np.uint8(arr)
    cv2.imwrite(out_path, arr)
    return out_path


def create_split(source_images, dest_root, val_size=0.2, test_size=0.1, seed=42):
    random.seed(seed)
    imgs = list(source_images)
    train_val, test = train_test_split(imgs, test_size=test_size, random_state=seed)
    train, val = train_test_split(train_val, test_size=val_size/(1-test_size), random_state=seed)

    for t, subset in [('train', train), ('val', val), ('test', test)]:
        img_dst = Path(dest_root) / 'images' / t
        lbl_dst = Path(dest_root) / 'labels' / t
        img_dst.mkdir(parents=True, exist_ok=True)
        lbl_dst.mkdir(parents=True, exist_ok=True)
        for img in subset:
            img_path = Path(img)
            # copiar imagen
            shutil.copy(img_path, img_dst / img_path.name)
            # copiar label si existe
            lbl = Path('data/labels') / img_path.parent.name / (img_path.stem + '.txt')
            if lbl.exists():
                shutil.copy(lbl, lbl_dst / (img_path.stem + '.txt'))

    return {'train': len(train), 'val': len(val), 'test': len(test)}