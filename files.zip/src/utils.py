# src/utils.py
import os
from pathlib import Path


def ensure_dirs(paths):
    for p in paths:
        Path(p).mkdir(parents=True, exist_ok=True)


def read_classes_from_yaml(yaml_path):
    import yaml
    with open(yaml_path, 'r') as f:
        cfg = yaml.safe_load(f)
    return cfg