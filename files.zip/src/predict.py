# src/predict.py
from ultralytics import YOLO
import argparse
import os
from pathlib import Path
import cv2


def run_inference(weights: str, source: str, conf: float = 0.25, save_dir: str = '../preds'):
    model = YOLO(weights)
    Path(save_dir).mkdir(parents=True, exist_ok=True)
    results = model.predict(source=source, conf=conf, save=True, save_dir=save_dir)
    print('Inferencia completada. Resultados en:', save_dir)
    return results


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--weights', type=str, required=True)
    parser.add_argument('--source', type=str, default='../data/images/test')
    parser.add_argument('--conf', type=float, default=0.25)
    parser.add_argument('--save_dir', type=str, default='../preds')
    args = parser.parse_args()
    run_inference(args.weights, args.source, args.conf, args.save_dir)