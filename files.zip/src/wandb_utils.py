# src/wandb_utils.py
"""
Funciones para inicializar y configurar wandb para entrenamiento y seguimiento.
"""
import wandb
import os


def init_wandb(project_name='dent-yolo', run_name=None, config=None):
    """
    Inicializa un run de wandb. Asegúrate de haber hecho `wandb login` previamente
    (o tener WANDB_API_KEY en env).
    """
    try:
        wandb.init(project=project_name, name=run_name, config=config)
    except Exception as e:
        print('Error iniciando wandb:', e)
        return None
    return wandb