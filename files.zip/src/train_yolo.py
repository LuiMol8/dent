# src/train_yolo.py
"""
Script avanzado para entrenar un modelo YOLOv8 usando la librería ultralytics.
Provee hooks para logging y manejo de checkpoints.
"""
import argparse
from ultralytics import YOLO
import os
from pathlib import Path
from utils import ensure_dirs, read_classes_from_yaml
import wandb


def train(cfg: str, epochs: int = 100, batch: int = 8, imgsz: int = 640, pretrained: str = 'yolov8s.pt', save_dir: str = '../runs', use_wandb: bool = True):
    cfg_path = Path(cfg)
    assert cfg_path.exists(), f"Archivo de dataset no encontrado: {cfg}"

    # crear directorios
    ensure_dirs([save_dir, 'runs'])

    # Inicializar wandb si se solicita
    if use_wandb:
        try:
            wandb.init(project='dent-yolo', config={'epochs': epochs, 'batch': batch, 'imgsz': imgsz})
        except Exception as e:
            print('Advertencia: wandb no inicializado:', e)

    # Cargar modelo preentrenado
    model = YOLO(pretrained)

    # Entrenamiento
    model.train(data=str(cfg_path), epochs=epochs, batch=batch, imgsz=imgsz, project=save_dir, name='dental_yolo', cache=True)

    print('Entrenamiento finalizado. Pesos en:', Path(save_dir)/'dental_yolo')
    if use_wandb:
        wandb.finish()


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--cfg', type=str, default='../yolo_dataset.yaml')
    parser.add_argument('--epochs', type=int, default=100)
    parser.add_argument('--batch', type=int, default=8)
    parser.add_argument('--imgsz', type=int, default=640)
    parser.add_argument('--pretrained', type=str, default='yolov8s.pt')
    parser.add_argument('--save_dir', type=str, default='../runs')
    parser.add_argument('--no-wandb', action='store_true', help='Desactivar logging en wandb')
    args = parser.parse_args()
    train(args.cfg, args.epochs, args.batch, args.imgsz, args.pretrained, args.save_dir, use_wandb=not args.no_wandb)