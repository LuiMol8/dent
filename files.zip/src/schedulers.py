# src/schedulers.py
"""
Utilidades para construir políticas de LR / schedulers que se pueden usar como referencia
si creas tu propio loop de entrenamiento. Ultralytics maneja schedulers internamente,
pero estas funciones son útiles para experiments rápidos.
"""
import math


def cosine_lr(initial_lr, final_lr, total_epochs, epoch):
    """Cosine annealing lr (scalar)."""
    if epoch >= total_epochs:
        return final_lr
    cos_out = math.cos(math.pi * epoch / total_epochs) + 1
    lr = final_lr + 0.5 * (initial_lr - final_lr) * cos_out
    return lr


def step_lr(initial_lr, drop_factor, step_size, epoch):
    """Step LR that drops every step_size epochs."""
    steps = epoch // step_size
    return initial_lr * (drop_factor ** steps)